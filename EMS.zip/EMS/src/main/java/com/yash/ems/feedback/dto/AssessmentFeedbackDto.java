package com.yash.ems.feedback.dto;


import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssessmentFeedbackDto {
    private Long assessmentFeedbackId;
    private Long employeeId;
    private Long  assessmentId;
    @JsonManagedReference
    private List<SkillRatingDto> skillRatingList;
}
    