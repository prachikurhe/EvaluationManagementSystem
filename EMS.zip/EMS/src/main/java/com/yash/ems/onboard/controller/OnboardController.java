package com.yash.ems.onboard.controller;

import com.yash.ems.model.Employee;
import com.yash.ems.onboard.dto.EmployeeDto;
import com.yash.ems.onboard.mapper.EmployeeMapper;
import com.yash.ems.onboard.service.OnboardService;
import com.yash.ems.report.controller.BasicController;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * This class s used to expose rest api for report module.
 *
 * @author prachi.kurhe
 * @since 01--3-2023
 */
@RestController
@RequestMapping("/onboard")
@RequiredArgsConstructor
public class OnboardController implements BasicController<EmployeeDto, Long> {

    private final OnboardService<Employee, Long> onboardService;
    private final EmployeeMapper employeeMapper;

    /**
     * @param id
     * @return
     */
    @Override
    public EmployeeDto get(Long id) {
        Employee employee = onboardService.get(id);
        return employeeMapper.convertToEmployeeDto(employee);
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public EmployeeDto save(EmployeeDto entity) {
        Employee employee = onboardService.save(employeeMapper.convertToEmployee(entity));
        return employeeMapper.convertToEmployeeDto(employee);
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public EmployeeDto update(EmployeeDto entity) {
        Employee employee = onboardService.save(employeeMapper.convertToEmployee(entity));
        onboardService.get(employee.getEmployeeId());
        return employeeMapper.convertToEmployeeDto(employee);
    }

    /**
     * @param entity
     */
    @Override
    public void delete(EmployeeDto entity) {
        Employee employee = onboardService.get(entity.getEmployeeId());
        onboardService.delete(employee);
    }

    /**
     * @return
     */
    @Override
    public List<EmployeeDto> getAll() {
        List<Employee> employeeList = onboardService.getAll();
        return employeeMapper.convertToEmployeeDtoList(employeeList);
    }
}
