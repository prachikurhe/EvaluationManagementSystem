package com.yash.ems.model;


import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;

import lombok.*;

import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
//@Entity
//@Table(name = "assessment")
public class Assessment {
    @Id
    @GeneratedValue
    private Long assessmentId;
    private String assessmentName;

    @OneToOne
    @JoinColumn(name = "evaluationFormId", referencedColumnName = "evaluationFormId")
    private EvaluationForm evaluationForm;

    @JsonManagedReference
    @ManyToMany
    @JoinTable(name = "assessment-employee-mapping",
            joinColumns = {@JoinColumn(name = "assessmentId")},
            inverseJoinColumns = {@JoinColumn(name = "employeeId")}
    )
    private Set<Employee> candidates;
}
