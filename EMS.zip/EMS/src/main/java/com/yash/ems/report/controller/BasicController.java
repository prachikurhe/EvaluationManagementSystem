package com.yash.ems.report.controller;

import org.springframework.web.bind.annotation.*;

import java.util.List;

public interface BasicController<T, ID> {
    @GetMapping("/{id}")
    T get(@PathVariable("id") ID id);

    @PostMapping
    T save(@RequestBody T entity);

    @PutMapping
    T update(@RequestBody T entity);

    @DeleteMapping
    void delete(@RequestBody T entity);

    @GetMapping
    List<T> getAll();
}
