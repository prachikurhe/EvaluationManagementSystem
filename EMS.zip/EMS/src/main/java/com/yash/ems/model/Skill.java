package com.yash.ems.model;


import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "skills")
@Builder
@ToString
public class Skill {
    @Id
    @GeneratedValue
    private Long skillId;
    private String skillName;
}
