package com.yash.ems.feedback.dto;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.yash.ems.onboard.dto.SkillDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SkillRatingDto {
    private Long skillRatingId;
    @JsonManagedReference
    private SkillDto skill;
    private int rating;
    private String remarks;
}
