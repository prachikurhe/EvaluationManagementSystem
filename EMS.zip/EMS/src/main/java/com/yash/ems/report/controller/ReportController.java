package com.yash.ems.report.controller;

import com.yash.ems.report.dto.UserReportDto;
import com.yash.ems.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.apache.logging.log4j.util.Strings.isNotBlank;

/**
 * This class s used to expose rest api for report module.
 *
 * @author prachi.kurhe
 * @since 01-03-2023
 */
@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class ReportController {
    private final ReportService reportService;

    /**
     * @param feedbackId  This is the unique id of associate.
     *                <p>
     *                This Api s used to return user report associated to provided event by user id.\n
     * @return This will return user of report
     */
    @GetMapping("/{feedbackId}")
    public UserReportDto getReportByFeedbackId(@PathVariable("feedbackId") long feedbackId) {
        return reportService.getReportByFeedBackId(feedbackId);
    }

    /**
     * This Api s used to return All report associated to provided event.\n
     * Or all user reports will be return.
     *
     * @return This will return list of reports
     */
    @GetMapping
    public List<UserReportDto> getReports() {
        return reportService.getReports();
    }

}
