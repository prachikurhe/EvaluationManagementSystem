package com.yash.ems.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@Entity
//@Table(name = "skill-ratings-mappings")
public class SkillRating {
    @Id
    @GeneratedValue
    private Long skillRatingId;

    @OneToOne
    @JoinColumn(name = "skill_id", referencedColumnName = "skillId")
    private Skill skill;

    private int rating;
    private String remarks;
}
