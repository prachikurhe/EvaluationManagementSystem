package com.yash.ems.feedback.service.impl;

import com.yash.ems.feedback.service.FeedbackService;
import com.yash.ems.model.AssessmentFeedback;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FeedbackServiceImpl implements FeedbackService<AssessmentFeedback, Long> {
    /**
     * @param aLong
     * @return
     */
    @Override
    public AssessmentFeedback get(Long aLong) {
        return null;
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public AssessmentFeedback save(AssessmentFeedback entity) {
        return null;
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public AssessmentFeedback update(AssessmentFeedback entity) {
        return null;
    }

    /**
     * @param entity
     */
    @Override
    public void delete(AssessmentFeedback entity) {

    }

    /**
     * @return
     */
    @Override
    public List<AssessmentFeedback> getAll() {
        return null;
    }
}
