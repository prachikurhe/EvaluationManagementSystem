package com.yash.ems.onboard.service;

import com.yash.ems.model.Employee;
import com.yash.ems.onboard.EmployeeNotFoundException;
import com.yash.ems.onboard.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OnboardServiceImpl implements OnboardService<Employee, Long>{

    private final EmployeeRepository employeeRepository;
    /**
     * @param id
     * @return
     */
    @Override
    public Employee get(Long id) {
        return employeeRepository.findById(id).orElseThrow(EmployeeNotFoundException :: new);
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public Employee save(Employee entity) {
        return employeeRepository.save(entity);
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public Employee update(Employee entity) {
        return employeeRepository.save(entity);
    }

    /**
     * @param entity
     */
    @Override
    public void delete(Employee entity) {
        employeeRepository.deleteById(entity.getEmployeeId());
    }

    /**
     * @return
     */
    @Override
    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }
}
