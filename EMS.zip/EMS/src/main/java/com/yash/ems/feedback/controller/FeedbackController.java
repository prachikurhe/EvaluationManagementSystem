package com.yash.ems.feedback.controller;

import com.yash.ems.feedback.dto.AssessmentFeedbackDto;
import com.yash.ems.feedback.mapper.FeedbackMapper;
import com.yash.ems.feedback.service.FeedbackService;
import com.yash.ems.model.AssessmentFeedback;
import com.yash.ems.report.controller.BasicController;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * This class s used to expose rest api for report module.
 *
 * @author prachi.kurhe
 * @since 06-3-2023
 */
@RestController
@RequestMapping("/feedback")
@RequiredArgsConstructor
public class FeedbackController implements BasicController<AssessmentFeedbackDto, Long> {
    private final FeedbackService<AssessmentFeedback, Long> feedbackService;
    private final FeedbackMapper feedbackMapper;

    /**
     * @param id
     * @return
     */
    @Override
    public AssessmentFeedbackDto get(Long id) {
        AssessmentFeedback assessmentFeedback = feedbackService.get(id);
        return feedbackMapper.convertToAssessmentFeedbackDto(assessmentFeedback);
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public AssessmentFeedbackDto save(AssessmentFeedbackDto entity) {
        AssessmentFeedback assessmentFeedback = feedbackMapper.convertToAssessmentFeedback(entity);
        return feedbackMapper.convertToAssessmentFeedbackDto(feedbackService.save(assessmentFeedback));
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public AssessmentFeedbackDto update(AssessmentFeedbackDto entity) {
        AssessmentFeedback assessmentFeedback = feedbackMapper.convertToAssessmentFeedback(entity);
        feedbackService.get(assessmentFeedback.getAssessmentFeedbackId());
        return feedbackMapper.convertToAssessmentFeedbackDto(feedbackService.save(assessmentFeedback));
    }

    /**
     * @param entity
     */
    @Override
    public void delete(AssessmentFeedbackDto entity) {
        AssessmentFeedback assessmentFeedback = feedbackService.get(entity.getAssessmentFeedbackId());
        feedbackService.delete(assessmentFeedback);
    }

    /**
     * @return
     */
    @Override
    public List<AssessmentFeedbackDto> getAll() {
        List<AssessmentFeedback> assessmentFeedbacks = feedbackService.getAll();
        return feedbackMapper.convertToAssessmentFeedbackDtoList(assessmentFeedbacks);
    }
}
