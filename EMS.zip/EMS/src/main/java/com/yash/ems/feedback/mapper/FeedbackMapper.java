package com.yash.ems.feedback.mapper;

import com.yash.ems.feedback.dto.AssessmentFeedbackDto;
import com.yash.ems.model.AssessmentFeedback;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring")
public interface FeedbackMapper {

    @Mappings(value = {
            @Mapping(source = "assessmentFeedback.employee.employeeId", target = "employeeId"),
            @Mapping(source = "assessmentFeedback.assessment.assessmentId", target = "assessmentId")
    }
    )
    AssessmentFeedbackDto convertToAssessmentFeedbackDto(AssessmentFeedback assessmentFeedback);

    @Mappings(value = {
            @Mapping(target = "employee.employeeId", source = "assessmentFeedbackDto.employeeId"),
            @Mapping(target = "assessment.assessmentId", source = "assessmentFeedbackDto.assessmentId")

    })
    AssessmentFeedback convertToAssessmentFeedback(AssessmentFeedbackDto assessmentFeedbackDto);

    List<AssessmentFeedbackDto> convertToAssessmentFeedbackDtoList(List<AssessmentFeedback> list);
}
