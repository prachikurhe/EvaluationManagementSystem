package com.yash.ems.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;

import lombok.*;

import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
//@Entity
//@Table(name = "evaluation-form")
public class EvaluationForm {
    @Id
    @GeneratedValue
    private Long evaluationFormId;
    private String evaluationFormName;
    private int requiredExp;
    private String jobDescription;

    @JsonManagedReference
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "evaluation-form-skill-mapping",
            joinColumns = {@JoinColumn(name = "evaluationFormId")},
            inverseJoinColumns = {@JoinColumn(name = "skillId")}
    )
    private Set<Skill> requiredSkills;
}
