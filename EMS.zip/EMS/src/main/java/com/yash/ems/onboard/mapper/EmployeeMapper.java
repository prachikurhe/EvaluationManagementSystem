package com.yash.ems.onboard.mapper;

import com.yash.ems.model.Employee;
import com.yash.ems.onboard.dto.EmployeeDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EmployeeMapper{
    Employee convertToEmployee(EmployeeDto source);
    EmployeeDto convertToEmployeeDto(Employee source);

    List<EmployeeDto> convertToEmployeeDtoList(List<Employee> source);
}
