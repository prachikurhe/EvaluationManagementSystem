package com.yash.ems.feedback.service;

import com.yash.ems.report.service.BasicService;

public interface FeedbackService<AssessmentFeedback, Long>  extends BasicService<AssessmentFeedback, Long> {
}
