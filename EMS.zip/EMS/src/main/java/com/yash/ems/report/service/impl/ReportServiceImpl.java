package com.yash.ems.report.service.impl;

import com.yash.ems.report.dto.SkillResponseDto;
import com.yash.ems.report.dto.UserReportDto;
import com.yash.ems.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * This class is used to implement api specifications defined by {@link ReportService}.
 * @author prachi.kurhe
 * @since 01--3-2023
 */
@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {
    //TODO need to remove as this is the mock data .
    private static Map<Long, UserReportDto> userReportMap = new HashMap<>();
    private static final List<String> userNames = List.of(
            "Sachin",
            "Prachi",
            "Aniket",
            "Swati",
            "Aishwarya",
            "karishma"
    );

    static {
        int min = 1;
        int max = 5;
        long userId = 100;
        long feedbackId = 500;
        for (String username : userNames) {
            List<SkillResponseDto> skillResponseList = List.of(
                    SkillResponseDto.builder().skillName("Communication Skill")
                            .ratingReceived((int) (Math.random() * (max - min + 1) + min))
                            .remarks("good in communication")
                            .build(),
                    SkillResponseDto.builder().skillName("Coding skill")
                            .ratingReceived((int) (Math.random() * (max - min + 1) + min))
                            .remarks("excellent in coding")
                            .build(),
                    SkillResponseDto.builder()
                            .skillName("Presentation skill")
                            .ratingReceived((int) (Math.random() * (max - min + 1) + min))
                            .remarks("presentation skill is exceptional")
                            .build(),
                    SkillResponseDto.builder().skillName("Leadership skills")
                            .ratingReceived((int) (Math.random() * (max - min + 1) + min))
                            .remarks("beginner in leadership")
                            .build(),
                    SkillResponseDto.builder().skillName("Company value")
                            .ratingReceived((int) (Math.random() * (max - min + 1) + min))
                            .remarks("meet expectations")
                            .build(),
                    SkillResponseDto.builder().skillName("Dummy Skill")
                            .ratingReceived((int) (Math.random() * (max - min + 1) + min))
                            .remarks("meet expectations")
                            .build()
            );

            UserReportDto userReportDto = UserReportDto.builder()
                    .employeeId(userId)
                    .employeeName(username)
                    .feedbackId(feedbackId)
                    .createdOn(Date.from(Instant.now()))
                    .skillResponseList(skillResponseList)
                    .build();
//            System.out.println(userId+" ===== "+userReportDto);
            userReportMap.put(feedbackId, userReportDto);
            userId++;
            feedbackId++;
        }

    }


    /**
     * @param feedbackId This is the userid of associate
     * @return will be returning all user report for that event .
     */
    @Override
    public UserReportDto getReportByFeedBackId(long feedbackId) {
        return userReportMap.getOrDefault(feedbackId, UserReportDto.builder().build());
    }

    /**
     * @param eventId This event is created for client evaluation and feedback.
     * @return will be returning user report for that event.
     */
    @Override
    public List<UserReportDto> getReportByEventId(String eventId) {
        return new ArrayList<>(userReportMap.values());
    }

    /**
     * @return will be returning user reports.
     */
    @Override
    public List<UserReportDto> getReports() {
        return new ArrayList<>(userReportMap.values());
    }
}
