package com.yash.ems.onboard.dto;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeDto implements Serializable {
    private Long employeeId;
    private String employeeName;
    private int experienceInMonth;
    @JsonManagedReference
    private List<SkillDto> skills;
}
