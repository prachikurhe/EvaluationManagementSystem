package com.yash.ems.onboard.service;

import com.yash.ems.report.service.BasicService;

public interface OnboardService<Employee, Long> extends BasicService<Employee, Long> {
}
