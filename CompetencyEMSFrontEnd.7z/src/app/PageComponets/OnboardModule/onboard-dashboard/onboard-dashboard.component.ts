import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboard-dashboard',
  templateUrl: './onboard-dashboard.component.html',
  styleUrls: ['./onboard-dashboard.component.css']
})
export class OnboardDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
