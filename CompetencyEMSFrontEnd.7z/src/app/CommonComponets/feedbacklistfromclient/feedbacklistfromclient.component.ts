import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeFeedback } from 'src/app/model/employee-feedback';
import { EmployeeFeedbackService } from 'src/app/Services/employee-feedback.service';

@Component({
  selector: 'app-feedbacklistfromclient',
  templateUrl: './feedbacklistfromclient.component.html',
  styleUrls: ['./feedbacklistfromclient.component.css']
})
export class FeedbacklistfromclientComponent implements OnInit {

  employeeFeedbacks !: EmployeeFeedback[];

  constructor(private myrouter:Router, private service : EmployeeFeedbackService) { }

  ngOnInit(): void {
    this.listEmployeeFeedbacks();
}

  async listEmployeeFeedbacks() {
     this.service.getEmployeeFeedbacks().subscribe((data: EmployeeFeedback[]) => {
     this.employeeFeedbacks = data;
    });
  }

}
