export class Skill {
    id !: number;
    name !: string;
}
