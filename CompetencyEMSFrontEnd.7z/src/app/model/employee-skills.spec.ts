import { EmployeeSkills } from './employee-skills';

describe('EmployeeSkills', () => {
  it('should create an instance', () => {
    expect(new EmployeeSkills()).toBeTruthy();
  });
});
