export class fileupload {
    Upload: any;
    upload(file: File) {
      
    }
  
      
  }
  