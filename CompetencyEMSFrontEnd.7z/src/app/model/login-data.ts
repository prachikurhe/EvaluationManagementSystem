// export class LoginData {
   
    
//         userName!:String;
//         password!:String;
//         constructor(){}
//     }

