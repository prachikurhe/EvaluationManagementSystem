export default interface ReportFeedbackSkill{
    id:string;
    feedbackId: string;
    skillName: string
    skillId: string;
    ratingReceived: string;
    remarks: string;
}