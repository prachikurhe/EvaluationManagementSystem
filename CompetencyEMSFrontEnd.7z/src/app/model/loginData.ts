export class logingData {
    
    userName!:String;
    password!:String;
    constructor(){}
}