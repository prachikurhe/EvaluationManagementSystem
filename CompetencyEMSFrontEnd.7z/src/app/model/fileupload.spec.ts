import { Fileupload } from './fileupload';

describe('Fileupload', () => {
  it('should create an instance', () => {
    expect(new Fileupload()).toBeTruthy();
  });
});
