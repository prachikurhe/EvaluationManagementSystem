import { EmployeeFeedback } from './employee-feedback';

describe('EmployeeFeedback', () => {
  it('should create an instance', () => {
    expect(new EmployeeFeedback()).toBeTruthy();
  });
});
