export class ReportSkillRating {
  sum!: number;
  count!: number;
  constructor(sum1: number, count1: number) {
    this.sum = sum1;
    this.count= count1;
  }
 
}
