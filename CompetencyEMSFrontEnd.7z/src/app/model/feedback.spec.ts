import { Feedback } from './feedback';

describe('Feedback', () => {
  it('should create an instance', () => {
    expect(new Feedback()).toBeTruthy();
  });
});
