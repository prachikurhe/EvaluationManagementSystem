export class Skills {
    skillId!: number;
    skillName!: string;
}
