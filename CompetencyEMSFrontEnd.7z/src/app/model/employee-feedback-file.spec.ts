import { EmployeeFeedbackFile } from './employee-feedback-file';

describe('EmployeeFeedbackFile', () => {
  it('should create an instance', () => {
    expect(new EmployeeFeedbackFile()).toBeTruthy();
  });
});
