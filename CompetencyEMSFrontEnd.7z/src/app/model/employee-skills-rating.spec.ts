import { EmployeeSkillsRating } from './employee-skills-rating';

describe('EmployeeSkillsRating', () => {
  it('should create an instance', () => {
    expect(new EmployeeSkillsRating()).toBeTruthy();
  });
});
